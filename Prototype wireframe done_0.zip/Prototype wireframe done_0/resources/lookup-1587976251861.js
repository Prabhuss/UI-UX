(function(window, undefined) {
  var dictionary = {
    "46dbc419-af37-4449-9471-4be7dea52d57": "update screen",
    "717b2157-bbd3-4a81-8db6-a0e0f196b76c": "Menu",
    "3285a902-da73-4ae3-abb6-887c7919c43d": "ORDERS SCREEN",
    "002a2a9d-5c3f-4334-8837-73581ac6740c": "MY ACCOUNT SCREEN",
    "936b149a-ccd5-4bc4-9604-0f8536a867ed": "CHANGE SOCIETY",
    "77d5db9e-b203-4bf8-b5dc-2a534d8c1596": "Sub Category Search",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "launch screen",
    "61c29c0f-a6b1-475a-8203-d0319d6890b2": "LANDING SCREEN",
    "627e0e55-424c-470d-8842-0e8f22d49091": "Products Detail Screeen",
    "264cc93d-5a11-4027-bcaa-66ca47d12ba0": "notifications",
    "ab1a1d0d-e420-4c0f-8f44-a321645c01bf": "my profile screen",
    "ccde3d54-5c1f-4ad4-8e7e-82d6708aab82": "ADD TO CART",
    "59a9328e-e198-4750-95c2-c8ff760e0b99": "LANDING SCREEN POST LOGIN",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);