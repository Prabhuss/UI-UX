var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-46dbc419-af37-4449-9471-4be7dea52d57" class="screen growth-vertical devMobile canvas PORTRAIT firer commentable non-processed" alignment="left" name="update screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/46dbc419-af37-4449-9471-4be7dea52d57-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/46dbc419-af37-4449-9471-4be7dea52d57-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/46dbc419-af37-4449-9471-4be7dea52d57-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="167px" datasizeheight="25px" dataX="15" dataY="128" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">ADDRESS / </span><span id="rtr-s-Text_2_1">Society</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="57px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="155px" datasizeheight="28px" dataX="60" dataY="15" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Delivery Address</span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="200px" datasizeheight="63px" dataX="15" dataY="175" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">TRINITY &nbsp;#406 SARJAPUR ROAD 50013 <br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rounded_Label" class="pie rectangle firer click commentable non-processed"   datasizewidth="154px" datasizeheight="44px" dataX="194" dataY="119" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0">CHANGE ADDRESS</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="137px" datasizeheight="36px" dataX="15" dataY="316" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="25px" dataX="21" dataY="263" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">ADDRESS 1</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="105px" datasizeheight="20px" dataX="21" dataY="324" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">SELECT BLOCK</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="25px" dataX="19" dataY="401" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">ADDRESS 2</span></div></div></div></div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="139px" datasizeheight="38px" dataX="14" dataY="446" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="114px" datasizeheight="20px" dataX="17" dataY="455" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">ENTER NUMBER</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="180" datasizewidth="38px" datasizeheight="11px" dataX="14" dataY="24" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" d="M 0 5 L 38 5"  marker-end="url(#end-marker-s-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="141px" datasizeheight="40px" dataX="13" dataY="569" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="115px" datasizeheight="20px" dataX="26" dataY="579" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">ENTER PINCODE</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="25px" dataX="15" dataY="518" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">ADDRESS 3</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;