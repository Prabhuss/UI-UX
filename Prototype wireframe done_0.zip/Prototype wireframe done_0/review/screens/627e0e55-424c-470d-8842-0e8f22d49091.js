var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="695">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-627e0e55-424c-470d-8842-0e8f22d49091" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Products Detail Screeen" width="360" height="695">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/627e0e55-424c-470d-8842-0e8f22d49091-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/627e0e55-424c-470d-8842-0e8f22d49091-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/627e0e55-424c-470d-8842-0e8f22d49091-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="180px" datasizeheight="195px" dataX="81" dataY="69"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="36px" datasizeheight="34px" dataX="48" dataY="291" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="21px" datasizeheight="22px" dataX="55" dataY="297" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="10.5" cy="11.0" rx="10.5" ry="11.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="10.5" cy="11.0" rx="10.5" ry="11.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="28px" dataX="120" dataY="298" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">20</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="39px" datasizeheight="28px" dataX="161" dataY="298" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Milk</span></div></div></div></div>\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="22px" dataX="99" dataY="304"   alt="image" systemName="./images/8469f55e-75b9-4fa8-87d3-709629050b75.svg" overlay="#000000">\
          <svg preserveAspectRatio=\'none\' id="s-Image_2-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><title>rupee-01</title><path d="M50.9,12.3V7.4H13.7v4.9H26.6c5.4,0,10,3.2,11.2,7.5H13.7v4.9H37.8C36.5,29,32,32.2,26.6,32.2H13.7V37H24.9L36.6,58.9l4.6-2.5L30.6,36.5c6.3-1.4,11.2-6.1,12.2-11.9h8.1V19.7H42.8a14.88,14.88,0,0,0-4-7.5l12.1,0.1h0Z"/></svg>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="93px" datasizeheight="28px" dataX="217" dataY="298" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">2 Packets</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="107px" datasizeheight="28px" dataX="14" dataY="344" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Description</span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="169px" dataX="23" dataY="388" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">j&#039;aime le glace et coud de chocolat et de gateaux. derriere l&#039;ecole voici le restaurant.<br />. &nbsp;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="144px" datasizeheight="51px" dataX="14" dataY="538" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0">IN &nbsp;STOCK</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="144px" datasizeheight="51px" dataX="14" dataY="605" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="97px" datasizeheight="20px" dataX="35" dataY="620" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">ADD TO CART </span></div></div></div></div>\
      <div id="s-Rectangle_5" class="pie rectangle firer commentable non-processed"   datasizewidth="144px" datasizeheight="51px" dataX="200" dataY="605" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_5_0">CANCEL</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="180" datasizewidth="38px" datasizeheight="11px" dataX="14" dataY="45" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" d="M 0 5 L 38 5"  marker-end="url(#end-marker-s-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Toggle-on-light" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="78px" datasizeheight="29px" dataX="200" dataY="550" >\
        <div id="s-Panel_3" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="73px" datasizeheight="27px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="36px" datasizeheight="16px" dataX="27" dataY="5" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_3_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="23px" datasizeheight="23px" dataX="20" dataY="2" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_2)">\
                                  <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape firer click commentable non-processed" cx="11.5" cy="11.5" rx="11.5" ry="11.5">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                                  <ellipse cx="11.5" cy="11.5" rx="11.5" ry="11.5">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_2" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_2_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_4" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="78px" datasizeheight="29px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_6" class="pie rectangle firer commentable non-processed"   datasizewidth="36px" datasizeheight="16px" dataX="27" dataY="5" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_6_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="23px" datasizeheight="23px" dataX="47" dataY="2" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_4)">\
                                  <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape firer click commentable non-processed" cx="11.5" cy="11.5" rx="11.5" ry="11.5">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                                  <ellipse cx="11.5" cy="11.5" rx="11.5" ry="11.5">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_4" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_4_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_1" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="76px" datasizeheight="27px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
          </div>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;