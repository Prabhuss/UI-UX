var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="1938">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-59a9328e-e198-4750-95c2-c8ff760e0b99" class="screen growth-vertical devMobile canvas PORTRAIT firer commentable non-processed" alignment="left" name="LANDING SCREEN POST LOGIN" width="360" height="1938">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/59a9328e-e198-4750-95c2-c8ff760e0b99-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/59a9328e-e198-4750-95c2-c8ff760e0b99-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/59a9328e-e198-4750-95c2-c8ff760e0b99-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Rounded_Label" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="59px" dataX="0" dataY="78" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="21" dataY="96"  rotationdeg="70" alt="image" systemName="./images/8a8f9813-4504-4674-8532-4c5b601dad7f.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>\
      </div>\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="38px" dataX="313" dataY="22"   alt="image" systemName="./images/dc22af1d-bdeb-4639-ae16-d0f290cd37b5.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>\
      </div>\
      <div id="s-Image_72" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="38px" dataX="17" dataY="22"   alt="image" systemName="./images/2861157e-4211-4bb9-bbac-4bd3127192d6.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="201px" datasizeheight="20px" dataX="63" dataY="98" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">SEARCH 50,000+ PRODUCTS</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="143" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="360px" datasizeheight="2px" dataX="0" dataY="236" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 360 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="303px" datasizeheight="25px" dataX="31" dataY="177" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">50% OFF ON ALL MILK PRODUCTS!</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="108px" datasizeheight="102px" dataX="40" dataY="261" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="108px" datasizeheight="102px" dataX="213" dataY="261" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="shapewrapper-s-Line_3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="108px" datasizeheight="2px" dataX="40" dataY="382" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 108 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="108px" datasizeheight="2px" dataX="40" dataY="408" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 108 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="108px" datasizeheight="100px" dataX="40" dataY="262"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="108px" datasizeheight="100px" dataX="214" dataY="262"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="110px" datasizeheight="2px" dataX="216" dataY="429" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 110 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="75px" datasizeheight="35px" dataX="56" dataY="448" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0">ADD</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="75px" datasizeheight="35px" dataX="239" dataY="447" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0">ADD</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="shapewrapper-s-Line_7" class="shapewrapper shapewrapper-s-Line_7 non-processed"   datasizewidth="108px" datasizeheight="2px" dataX="40" dataY="429" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_7" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_7" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 108 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_8" class="shapewrapper shapewrapper-s-Line_8 non-processed"   datasizewidth="110px" datasizeheight="2px" dataX="216" dataY="382" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_8" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_8" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 110 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_9" class="shapewrapper shapewrapper-s-Line_9 non-processed"   datasizewidth="110px" datasizeheight="2px" dataX="216" dataY="408" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_9" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_9" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 110 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Image_43" class="pie image firer ie-background commentable non-processed"   datasizewidth="83px" datasizeheight="80px" dataX="-15" dataY="541"   alt="image" systemName="./images/b0bb7876-4aac-4513-ace1-6c1ca0eb81cd.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
      <div id="s-Image_44" class="pie image firer ie-background commentable non-processed"   datasizewidth="83px" datasizeheight="80px" dataX="279" dataY="541"   alt="image" systemName="./images/0e06f456-b4cd-4160-9a63-13b3d833d42a.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/></svg>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="119px" datasizeheight="20px" dataX="113" dataY="556" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">ADVERTISEMENT</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="107px" datasizeheight="20px" dataX="119" dataY="581" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">(FAST MOVING)</span></div></div></div></div>\
      <div id="s-Rectangle_5" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="62px" dataX="0" dataY="661" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_5_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="113px" datasizeheight="25px" dataX="31" dataY="682" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">CATEGORIES</span></div></div></div></div>\
\
      <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="31" dataY="752"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="213" dataY="752"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="89px" datasizeheight="20px" dataX="36" dataY="873" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Milk Products</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="73px" datasizeheight="20px" dataX="230" dataY="873" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Vegetables</span></div></div></div></div>\
\
      <div id="s-Image_7" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="30" dataY="921"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_8" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="42px" datasizeheight="20px" dataX="60" dataY="1043" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Fruits </span></div></div></div></div>\
\
      <div id="s-Image_8" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="213" dataY="921"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_9" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="87px" datasizeheight="20px" dataX="223" dataY="1034" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">Bakery, Dairy </span></div></div></div></div>\
\
      <div id="s-Image_9" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="29" dataY="1102"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_10" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="20px" dataX="44" dataY="1214" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">Beverages</span></div></div></div></div>\
\
      <div id="s-Image_10" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="213" dataY="1102"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_11" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="80px" datasizeheight="20px" dataX="219" dataY="1214" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">Breakfast &amp; </span></div></div></div></div>\
      <div id="s-Text_12" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="46px" datasizeheight="20px" dataX="232" dataY="1062" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">&amp;</span><span id="rtr-s-Text_12_1"> Eggs</span></div></div></div></div>\
      <div id="s-Text_13" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="48px" datasizeheight="20px" dataX="239" dataY="1239" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Snacks</span></div></div></div></div>\
\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="30" dataY="1275"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_14" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="20px" dataX="29" dataY="1392" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">Foodgrains, Oil </span></div></div></div></div>\
      <div id="s-Text_15" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="20px" dataX="46" dataY="1417" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_15_0">&amp; Masala</span></div></div></div></div>\
\
      <div id="s-Image_12" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="213" dataY="1276"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_16" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="84px" datasizeheight="20px" dataX="225" dataY="1392" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_16_0">Pooja Needs</span></div></div></div></div>\
\
      <div id="s-Image_13" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="31" dataY="1475"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_17" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="95px" datasizeheight="20px" dataX="29" dataY="1597" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_17_0">Baby Products</span></div></div></div></div>\
\
      <div id="s-Image_14" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="217" dataY="1475"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_18" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="62px" datasizeheight="20px" dataX="240" dataY="1597" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_18_0">Beauty &amp; </span></div></div></div></div>\
      <div id="s-Text_19" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="20px" dataX="244" dataY="1625" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_19_0">H</span><span id="rtr-s-Text_19_1">ygiene</span></div></div></div></div>\
\
      <div id="s-Image_15" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="30" dataY="1686"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_20" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="89px" datasizeheight="20px" dataX="36" dataY="1808" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_20_0">Cleaning And </span></div></div></div></div>\
      <div id="s-Text_21" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="70px" datasizeheight="20px" dataX="44" dataY="1835" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_21_0">Household</span></div></div></div></div>\
\
      <div id="s-Image_16" class="pie image firer click ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="213" dataY="1686"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_22" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="20px" dataX="234" dataY="1816" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_22_0">Pet Care</span></div></div></div></div>\
      <div id="s-Rectangle_6" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="62px" dataX="0" dataY="1875" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_6_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Image_36" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="66" dataY="1882"   alt="image" systemName="./images/262799e9-74b6-49e3-a003-a6f805130303.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>\
      </div>\
      <div id="s-Image_17" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="159" dataY="1882"   alt="image" systemName="./images/7ab4ac16-ce42-4ceb-866f-e86123462be8.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_17-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_17 .cls-1{fill:#666;}</style></defs><title>qqq</title><path id="s-Image_17-sliders_side_2" data-name="sliders side 2" class="cls-1" d="M54,60H8a4,4,0,0,1-4-4V10A4,4,0,0,1,8,6H54a4,4,0,0,1,4,4V56A4,4,0,0,1,54,60ZM8,8a2,2,0,0,0-2,2V56a2,2,0,0,0,2,2H54a2,2,0,0,0,2-2V10a2,2,0,0,0-2-2H8Z"/><path class="cls-1" d="M16.33,24.81a4.08,4.08,0,1,0-4.08-4.08A4.08,4.08,0,0,0,16.33,24.81Zm0-6.54a2.45,2.45,0,1,1-2.45,2.45A2.45,2.45,0,0,1,16.33,18.27Z"/><path class="cls-1" d="M16.33,38.52a4.08,4.08,0,1,0-4.08-4.08A4.08,4.08,0,0,0,16.33,38.52Zm0-6.54a2.45,2.45,0,1,1-2.45,2.45A2.45,2.45,0,0,1,16.33,32Z"/><path class="cls-1" d="M16.33,51.22a4.08,4.08,0,1,0-4.08-4.08A4.08,4.08,0,0,0,16.33,51.22Zm0-6.54a2.45,2.45,0,1,1-2.45,2.45A2.45,2.45,0,0,1,16.33,44.68Z"/><path class="cls-1" d="M50.18,19.91h-25a0.82,0.82,0,1,0,0,1.63h25A0.82,0.82,0,1,0,50.18,19.91Z"/><path class="cls-1" d="M50.18,33.61h-25a0.82,0.82,0,1,0,0,1.63h25A0.82,0.82,0,1,0,50.18,33.61Z"/><path class="cls-1" d="M50.18,46.32h-25a0.82,0.82,0,1,0,0,1.63h25A0.82,0.82,0,1,0,50.18,46.32Z"/></svg>\
      </div>\
      <div id="s-Image_18" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="249" dataY="1882"   alt="image" systemName="./images/64bef399-7ce7-4551-84c2-47bfa4de96ae.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_18-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_18 .cls-1{fill:#666;}</style></defs><title>shop_cart</title><path class="cls-1" d="M10,53a3,3,0,1,0,3-3A3,3,0,0,0,10,53Zm4,0a1,1,0,1,1-1-1A1,1,0,0,1,14,53Z"/><path class="cls-1" d="M57,50a3,3,0,1,0,3,3A3,3,0,0,0,57,50Zm0,4a1,1,0,1,1,1-1A1,1,0,0,1,57,54Z"/><path class="cls-1" d="M5,10H9.26l8.45,27.24C13.18,38.46,10,43.64,10,47a1,1,0,0,0,1,1H59a1,1,0,0,0,0-2H12.12c0.59-2.67,3.3-6.61,7-7l40-4a1,1,0,0,0,.9-1V13a1,1,0,0,0-1-1H12L11,8.7A1,1,0,0,0,10,8H5A1,1,0,0,0,5,10Zm53,4V33.1L19.71,36.93,12.6,14H58Z"/></svg>\
      </div>\
      <div id="s-Text_23" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="41px" datasizeheight="20px" dataX="68" dataY="1918" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_23_0">Home</span></div></div></div></div>\
      <div id="s-Text_24" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="70px" datasizeheight="20px" dataX="147" dataY="1919" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_24_0">My Orders</span></div></div></div></div>\
      <div id="s-Text_25" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="20px" dataX="251" dataY="1918" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_25_0">My Cart</span></div></div></div></div>\
      <div id="s-Text_26" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="96px" datasizeheight="20px" dataX="125" dataY="209" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_26_0">(</span><span id="rtr-s-Text_26_1">PROMOTION)</span></div></div></div></div>\
      <div id="s-Text_27" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="131px" datasizeheight="25px" dataX="28" dataY="361" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_27_0">PARLE G 200 G</span></div></div></div></div>\
      <div id="s-Text_28" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="107px" datasizeheight="25px" dataX="215" dataY="361" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_28_0">MAGGI 250G</span></div></div></div></div>\
      <div id="s-Text_29" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="149px" datasizeheight="20px" dataX="-284" dataY="514" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_29_0">Type something here...</span></div></div></div></div>\
      <div id="s-Text_30" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="25px" dataX="56" dataY="385" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_30_0">50% OFF</span></div></div></div></div>\
      <div id="s-Text_31" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="29" dataY="383" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_31_0"></span></div></div></div></div>\
      <div id="s-Text_32" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="25px" dataX="233" dataY="385" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_32_0">10% OFF</span></div></div></div></div>\
      <div id="s-Text_33" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="25px" dataX="89" dataY="409" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_33_0">15</span></div></div></div></div>\
      <div id="s-Image_19" class="pie image firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="22px" dataX="56" dataY="408"   alt="image" systemName="./images/28e541f1-8882-49e6-aae0-b2c654914b26.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' id="s-Image_19-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><title>rupee-01</title><path d="M50.9,12.3V7.4H13.7v4.9H26.6c5.4,0,10,3.2,11.2,7.5H13.7v4.9H37.8C36.5,29,32,32.2,26.6,32.2H13.7V37H24.9L36.6,58.9l4.6-2.5L30.6,36.5c6.3-1.4,11.2-6.1,12.2-11.9h8.1V19.7H42.8a14.88,14.88,0,0,0-4-7.5l12.1,0.1h0Z"/></svg>\
      </div>\
      <div id="s-Image_20" class="pie image firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="22px" dataX="239" dataY="411"   alt="image" systemName="./images/3b127766-ea33-4a31-9c6b-4fbd3c89ccdc.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' id="s-Image_20-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><title>rupee-01</title><path d="M50.9,12.3V7.4H13.7v4.9H26.6c5.4,0,10,3.2,11.2,7.5H13.7v4.9H37.8C36.5,29,32,32.2,26.6,32.2H13.7V37H24.9L36.6,58.9l4.6-2.5L30.6,36.5c6.3-1.4,11.2-6.1,12.2-11.9h8.1V19.7H42.8a14.88,14.88,0,0,0-4-7.5l12.1,0.1h0Z"/></svg>\
      </div>\
      <div id="s-Text_34" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="22px" datasizeheight="25px" dataX="267" dataY="409" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_34_0">50</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;