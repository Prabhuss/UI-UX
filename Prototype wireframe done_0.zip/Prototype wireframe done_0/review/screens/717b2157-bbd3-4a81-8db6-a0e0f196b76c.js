var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-717b2157-bbd3-4a81-8db6-a0e0f196b76c" class="screen growth-vertical devMobile canvas PORTRAIT firer commentable non-processed" alignment="left" name="Menu" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/717b2157-bbd3-4a81-8db6-a0e0f196b76c-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/717b2157-bbd3-4a81-8db6-a0e0f196b76c-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/717b2157-bbd3-4a81-8db6-a0e0f196b76c-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Image_96" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="10" dataY="470"   alt="image" systemName="./images/209ae3d4-be72-482e-a3c1-ef11a7c250e9.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/></svg>\
      </div>\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="10" dataY="215"   alt="image" systemName="./images/b1e89903-e02b-4c56-8a14-6a9412842446.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>\
      </div>\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed"   datasizewidth="44px" datasizeheight="36px" dataX="10" dataY="300"   alt="image" systemName="./images/1aa5743f-550c-4e47-b611-6b575138701a.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_3-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_3 .cls-1{fill:#666;}</style></defs><title>alarm</title><path class="cls-1" d="M55,52a1,1,0,1,0,0-2h0a5,5,0,0,1-5-5.08l-1-13c-0.88-12.35-6.69-20.64-15-21.78V7a1,1,0,0,0-1-1H31a1,1,0,0,0-1,1v3.15c-8.31,1.14-14.12,9.43-15,21.77L14,45a5,5,0,0,1-5,5,1,1,0,0,0,0,2H55ZM13.9,50A6.84,6.84,0,0,0,16,45.08l1-13C17.87,19.88,23.76,12,32,12s14.13,7.88,15,20.08L48,45a7,7,0,0,0,2.11,5H13.9Z"/><path class="cls-1" d="M36.2,54.29a6,6,0,0,1-8.4,0,1,1,0,1,0-1.4,1.42,8,8,0,0,0,11.2,0A1,1,0,0,0,36.2,54.29Z"/></svg>\
      </div>\
      <div id="s-Image_12" class="pie image firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="12" dataY="387"   alt="image" systemName="./images/6773615a-dd50-47b5-ad93-f7ed74466638.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 15.5c-1.25 0-2.45-.2-3.57-.57-.35-.11-.74-.03-1.02.24l-2.2 2.2c-2.83-1.44-5.15-3.75-6.59-6.59l2.2-2.21c.28-.26.36-.65.25-1C8.7 6.45 8.5 5.25 8.5 4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.5c0-.55-.45-1-1-1zM19 12h2c0-4.97-4.03-9-9-9v2c3.87 0 7 3.13 7 7zm-4 0h2c0-2.76-2.24-5-5-5v2c1.66 0 3 1.34 3 3z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="141px" datasizeheight="25px" dataX="4" dataY="102" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Customer Name</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="3" dataY="105" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0"></span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="154px" datasizeheight="25px" dataX="3" dataY="142" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Address/Location</span></div></div></div></div>\
      <div id="s-Image_72" class="pie image firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="270" dataY="23"   alt="image" systemName="./images/640d44d9-b715-4e85-a5be-9a2944d038cf.svg" overlay="#B51F00">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="109px" datasizeheight="25px" dataX="62" dataY="220" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0"> My Account</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="113px" datasizeheight="25px" dataX="69" dataY="305" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Notifications</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="96px" datasizeheight="25px" dataX="78" dataY="392" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Contact Us</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="25px" dataX="86" dataY="475" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Logout</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="52px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Image_73" class="pie image firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="10" dataY="10"   alt="image" systemName="./images/2b7e251e-07e6-4777-9a8e-b792519be485.svg" overlay="#B51F00">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>\
      </div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="28px" dataX="62" dataY="12" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">Menu</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;