var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-none devMobile canvas PORTRAIT firer commentable non-processed" alignment="left" name="launch screen" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Image_43" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="60px" dataX="14" dataY="104"   alt="image" systemName="./images/302a8625-ec8c-463c-90b0-b0d85b3d3190.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
      <div id="s-Image_44" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="60px" dataX="300" dataY="104"   alt="image" systemName="./images/dc37ba90-4201-4f8d-b5a7-5c617e7aebf8.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/></svg>\
      </div>\
      <div id="s-Image_45" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="92px" dataX="-2" dataY="88"   alt="image" systemName="./images/3c01a48e-2b87-42f8-9153-65a69163d3ea.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
      <div id="s-Image_46" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="92px" dataX="310" dataY="88"   alt="image" systemName="./images/8c8e0374-3645-49e8-91ee-08658cee5b4a.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="171px" datasizeheight="28px" dataX="100" dataY="120" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">ROTATIONAL ADS</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="270px" datasizeheight="25px" dataX="47" dataY="204" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">ENTER YOUR PHONE NUMBER</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="270px" datasizeheight="50px" dataX="47" dataY="254" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0">MOBILE NUMBER (10 DIGITS)</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="343px" datasizeheight="15px" dataX="10" dataY="463" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">By clicking continue you agree to the privacy policy and terms of use </span></div></div></div></div>\
      <div id="s-Rounded_Label" class="pie rectangle firer click commentable non-processed"   datasizewidth="243px" datasizeheight="59px" dataX="60" dataY="348" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0">CONTINUE</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="172" dataY="520" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0"></span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="82px" datasizeheight="20px" dataX="136" dataY="520" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Explore Now</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;