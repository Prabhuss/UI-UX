var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-002a2a9d-5c3f-4334-8837-73581ac6740c" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="MY ACCOUNT SCREEN" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/002a2a9d-5c3f-4334-8837-73581ac6740c-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/002a2a9d-5c3f-4334-8837-73581ac6740c-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/002a2a9d-5c3f-4334-8837-73581ac6740c-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="53px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="131px" datasizeheight="28px" dataX="124" dataY="13" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">MY ACCOUNT</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="180" datasizewidth="38px" datasizeheight="11px" dataX="19" dataY="22" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" d="M 0 5 L 38 5"  marker-end="url(#end-marker-s-Line_1">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_1" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="103px" datasizeheight="25px" dataX="36" dataY="140" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Anika Singh</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="110px" datasizeheight="25px" dataX="36" dataY="184" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">9999999999</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="20px" dataX="36" dataY="226" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0"></span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="175px" datasizeheight="25px" dataX="36" dataY="227" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Anika_s@gmail.com</span></div></div></div></div>\
      <div id="s-Image_119" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="29" dataY="294"   alt="image" systemName="./images/cbf1a40b-b17d-45f3-a2c4-598390059a6d.svg" overlay="#000000">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/></svg>\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="80px" datasizeheight="25px" dataX="93" dataY="299" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">My Order</span></div></div></div></div>\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="29" dataY="386"   alt="image" systemName="./images/e9405708-2f6a-402c-aa27-dd11dc2475d7.svg" overlay="#000000">\
          <svg preserveAspectRatio=\'none\' id="s-Image_2-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_2 .cls-1{fill:#666;}</style></defs><title>alarm</title><path class="cls-1" d="M55,52a1,1,0,1,0,0-2h0a5,5,0,0,1-5-5.08l-1-13c-0.88-12.35-6.69-20.64-15-21.78V7a1,1,0,0,0-1-1H31a1,1,0,0,0-1,1v3.15c-8.31,1.14-14.12,9.43-15,21.77L14,45a5,5,0,0,1-5,5,1,1,0,0,0,0,2H55ZM13.9,50A6.84,6.84,0,0,0,16,45.08l1-13C17.87,19.88,23.76,12,32,12s14.13,7.88,15,20.08L48,45a7,7,0,0,0,2.11,5H13.9Z"/><path class="cls-1" d="M36.2,54.29a6,6,0,0,1-8.4,0,1,1,0,1,0-1.4,1.42,8,8,0,0,0,11.2,0A1,1,0,0,0,36.2,54.29Z"/></svg>\
      </div>\
      <div id="s-Text_7" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="113px" datasizeheight="25px" dataX="93" dataY="391" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Notifications</span></div></div></div></div>\
      <div id="s-Rounded_Label" class="pie rectangle firer click commentable non-processed"   datasizewidth="165px" datasizeheight="49px" dataX="195" dataY="92" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0">EDIT</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;