var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-61c29c0f-a6b1-475a-8203-d0319d6890b2" class="screen growth-vertical devMobile canvas PORTRAIT firer commentable non-processed" alignment="left" name="LANDING SCREEN" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/61c29c0f-a6b1-475a-8203-d0319d6890b2-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/61c29c0f-a6b1-475a-8203-d0319d6890b2-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/61c29c0f-a6b1-475a-8203-d0319d6890b2-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Image_43" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="60px" dataX="14" dataY="104"   alt="image" systemName="./images/302a8625-ec8c-463c-90b0-b0d85b3d3190.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
      <div id="s-Image_44" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="60px" dataX="300" dataY="104"   alt="image" systemName="./images/dc37ba90-4201-4f8d-b5a7-5c617e7aebf8.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="171px" datasizeheight="28px" dataX="100" dataY="120" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">ROTATIONAL ADS</span></div></div></div></div>\
      <div id="s-Image_45" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="92px" dataX="0" dataY="88"   alt="image" systemName="./images/be7ea3cb-1580-4baf-a90f-62c70f8f6602.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/></svg>\
      </div>\
      <div id="s-Image_46" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="92px" dataX="310" dataY="88"   alt="image" systemName="./images/a9c3ef57-5b62-4854-8165-93db65d8757d.svg" overlay="#7D7D7D">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"/></svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="243px" datasizeheight="28px" dataX="68" dataY="202" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">ENTER YOUR 4 DIGIT OTP</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="59px" dataX="31" dataY="279" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="59px" dataX="113" dataY="279" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="59px" dataX="194" dataY="279" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle firer commentable non-processed"   datasizewidth="60px" datasizeheight="59px" dataX="277" dataY="279" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rounded_Label" class="pie rectangle firer click commentable non-processed"   datasizewidth="243px" datasizeheight="59px" dataX="64" dataY="384" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0">ENTER</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;