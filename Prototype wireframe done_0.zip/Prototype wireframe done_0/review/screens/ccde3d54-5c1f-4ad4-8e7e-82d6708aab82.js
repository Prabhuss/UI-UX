var content='<div class="ui-page" deviceName="androidPhone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1587976251861-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ccde3d54-5c1f-4ad4-8e7e-82d6708aab82" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ADD TO CART" width="360" height="640">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ccde3d54-5c1f-4ad4-8e7e-82d6708aab82-1587976251861.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/ccde3d54-5c1f-4ad4-8e7e-82d6708aab82-1587976251861-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/ccde3d54-5c1f-4ad4-8e7e-82d6708aab82-1587976251861-ie8.css" /><![endif]-->\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="360px" datasizeheight="57px" dataX="0" dataY="0" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="72px" datasizeheight="28px" dataX="134" dataY="15" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">My Cart</span></div></div></div></div>\
      <div id="s-Image_13" class="pie image firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="36px" dataX="221" dataY="11"   alt="image" systemName="./images/2b60392f-3e95-4cc0-957b-941874b60d94.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_13-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_13 .cls-1{fill:#666;}</style></defs><title>shop_cart</title><path class="cls-1" d="M10,53a3,3,0,1,0,3-3A3,3,0,0,0,10,53Zm4,0a1,1,0,1,1-1-1A1,1,0,0,1,14,53Z"/><path class="cls-1" d="M57,50a3,3,0,1,0,3,3A3,3,0,0,0,57,50Zm0,4a1,1,0,1,1,1-1A1,1,0,0,1,57,54Z"/><path class="cls-1" d="M5,10H9.26l8.45,27.24C13.18,38.46,10,43.64,10,47a1,1,0,0,0,1,1H59a1,1,0,0,0,0-2H12.12c0.59-2.67,3.3-6.61,7-7l40-4a1,1,0,0,0,.9-1V13a1,1,0,0,0-1-1H12L11,8.7A1,1,0,0,0,10,8H5A1,1,0,0,0,5,10Zm53,4V33.1L19.71,36.93,12.6,14H58Z"/></svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="146px" datasizeheight="25px" dataX="15" dataY="99" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Delivery Address</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="289px" datasizeheight="21px" dataX="15" dataY="145" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">TRINITY &nbsp;#406 SARJAPUR ROAD 50013 </span></div></div></div></div>\
      <div id="s-Rounded_Label" class="pie rectangle firer click commentable non-processed"   datasizewidth="189px" datasizeheight="46px" dataX="171" dataY="194" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_0">Update</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Rounded_Label_1" class="pie rectangle firer commentable non-processed"   datasizewidth="189px" datasizeheight="49px" dataX="171" dataY="262" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rounded_Label_1_0">Place Order</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="27" dataY="349"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="100px" dataX="27" dataY="485"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="370" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="118px" datasizeheight="2px" dataX="201" dataY="370" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 118 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="396" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="430" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="504" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="567" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_7" class="shapewrapper shapewrapper-s-Line_7 non-processed"   datasizewidth="130px" datasizeheight="2px" dataX="188" dataY="534" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_7" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_7" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 130 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_8" class="shapewrapper shapewrapper-s-Line_8 non-processed"  rotationdeg="180" datasizewidth="38px" datasizeheight="11px" dataX="27" dataY="24" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_8" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_8" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" d="M 0 5 L 38 5"  marker-end="url(#end-marker-s-Line_8">\
                      </path>\
                  </g>\
              </g>\
              <defs>\
      			<marker id="end-marker-s-Line_8" class="open endmarker" orient="0" stroke-width="0px" viewBox="0 0 100 100" refY="50" preserveAspectRatio="none" markerUnits="userSpaceOnUse">\
      				<path d="M 39.688716 40.466926 39.818418 60.051881 7.9118028 79.24773 C -6.6058565 88.636494 5.3977603 106.07944 19.844358 97.146562 L 99.610893 50.324254 21.53048 3.7613489 C 4.631474 -8.1505951 -6.7257532 14.353316 7.6523994 20.881971 Z"></path>\
      			</marker>\
              </defs>\
          </svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;